# Handoff: Vessel — Bottle-Sort Game Visual Redesign

## Overview
This package contains a **visual redesign** of a bottle / water-sort puzzle game
(original: a single-file HTML game, `Bottlesort`, included for reference). It
proposes two complete art directions for the **Home** and **Gameplay** screens,
designed mobile-first (portrait phone).

- **Proposal A · The Apothecary** — a sunlit (or candlelit) apothecary shelf:
  corked potion bottles, parchment labels, refractive glass, warm wood. Includes
  a **light/dark mode toggle**.
- **Proposal B · Neon Arcade** — a dark synthwave scene: glowing liquids, a
  perspective grid horizon, neon wordmark. (Intended to also gain a
  "sort-to-the-beat" play mode — not yet built.)

The two directions are meant to **coexist in the shipping game** as selectable
themes, with the light/dark toggle living at the top of the game screen.

---

## About the Design Files
The files in this bundle are **design references created in HTML/React-via-Babel** —
prototypes that communicate the intended *look*, *layout*, *color*, and *motion
intent*. **They are not production code to copy directly.**

The task is to **recreate these designs in the target game's real environment**
(e.g. a game engine, canvas/WebGL renderer, React Native, Unity, SwiftUI, or
whatever the team chooses if no codebase exists yet), using that environment's
established patterns, asset pipeline, and rendering capabilities.

> ### ⚠️ Scope split — please read
> The HTML prototypes deliberately **approximate** the dynamic qualities the
> client wants. **The visual design — composition, color, typography, glassware
> shapes, labels, backdrop, UI chrome, light/dark theming — is the deliverable
> to match.**
>
> **The following are explicitly handed to the implementing developer (Claude
> Code) to build *properly* in the target engine — the HTML versions are only
> rough indications of intent, not specs to port line-for-line:**
> 1. **Liquid physics** — believable fluid: real surface tension/meniscus,
>    sloshing with momentum & damping, settling, wave propagation.
> 2. **Bubbling / elemental effects** — rising bubbles, fizz, vapor/steam,
>    glints, caustics, ember/spark flourishes.
> 3. **Pour mechanics** — physically-plausible tilt, an arcing liquid stream
>    that responds to gravity and bottle angle, droplets, splash, ripple on
>    impact, volume conservation.
> 4. **True 3D** — the prototypes use CSS pseudo-3D/parallax only. Real depth
>    (3D glass with refraction, depth-sorted scene, lighting) is the dev's call
>    and should be implemented with the engine's 3D/shaders, not faked.
>
> Treat the motion in the prototypes as **mood/intent reference**. Build the real
> thing with the engine's particle systems, shaders, and physics.

---

## Fidelity
**High-fidelity for visual design; low-fidelity for motion/physics.**

- **Pixel-perfect to match:** colors, typography, spacing, glassware silhouettes,
  labels/corks, backdrops, HUD chrome, buttons, chips, the light/dark theming.
- **Intent-only (rebuild properly):** all liquid behavior, bubbling, pour
  animation, and 3D depth (see scope box above).

---

## Target Format
- **Platform:** Mobile, portrait.
- **Design frame:** 384 × 812 px (the prototypes render inside a 384×812 iOS
  device frame; that frame is scaffolding — not part of the design).
- **Safe-area top padding** in mocks ≈ 56–60px (status bar / notch).

---

## Design Tokens

### Typography
| Role | Apothecary | Neon Arcade |
|---|---|---|
| Display / headings | **Fraunces** (serif), 600, often *italic*, tracking −0.02em | **Chakra Petch** (sans), 700, tracking +0.01em |
| Body / labels | **Spectral** (serif) | **Space Grotesk** (sans) |
| Wordmark size | 70px, italic | 64px |
| Section kicker | 12–13px, uppercase, letter-spacing 0.40–0.42em | same |
| HUD title | 19px / 600 | 19–20px / 600 |
| Chip / caption | 10.5–12.5px, uppercase variants letter-spacing 0.04–0.18em | same |

Google Fonts import (all weights used):
`Fraunces:opsz,wght@9..144,400;500;600;700` · `Spectral:wght@400;500;600` ·
`Space Grotesk:wght@400;500;600;700` · `Chakra Petch:wght@500;600;700`

### Apothecary color tokens
**Light mode (default — sunlit honey-oak cabinet)**
- Backdrop: `radial-gradient(125% 85% at 50% -10%, #fff8ea, #f4e6c6 40%, #e7cf9f 76%, #d8b97f)`
- Shelf: `linear-gradient(#caa46a, #a87c44)`, top highlight `rgba(255,245,220,0.5)`
- Text fg `#5a3a1c` · title `#3a2410` · sub `rgba(90,58,28,0.6)` · accent `#b9742a`
- Chip bg `rgba(120,78,38,0.07)` · chip border `rgba(120,78,38,0.22)`
- Light pool / glow: `radial-gradient(ellipse, rgba(255,225,160,0.55), transparent 72%)`

**Dark mode (candlelit amber cabinet)**
- Backdrop: `radial-gradient(125% 80% at 50% 108%, rgba(255,180,90,0.34), transparent 60%), radial-gradient(110% 85% at 50% -8%, #56381f, #311e10 60%, #20130a)`
- Shelf: `linear-gradient(#7a542c, #4a3018)`
- Text fg `#f1e2cd` · title `#f8ecd6` · sub `rgba(241,226,205,0.62)` · accent `#f0c074`
- Chip bg `rgba(255,226,180,0.08)` · chip border `rgba(255,214,156,0.30)`

**Primary CTA (both modes):** `linear-gradient(#f3c97f, #d18b34)`, text `#3a2410`,
shadow `0 8px 20px rgba(150,95,35,0.4), inset 0 1px 0 rgba(255,255,255,0.6)`, radius 14px.

**Apothecary liquid palette** (each = bright face `a` / shadow side `b`, used as a
left→center→right horizontal gradient `b → a → b`):
| # | Name | a (bright) | b (shadow) |
|---|---|---|---|
| 0 | rose elixir | `#ff8fa0` | `#e23b5d` |
| 1 | amber tincture | `#ffce7a` | `#ef8a1e` |
| 2 | citron cordial | `#fff39b` | `#ecc02c` |
| 3 | verdant draught | `#9ef0a6` | `#37b35a` |
| 4 | aqua vitae | `#8ff0e2` | `#19a89a` |
| 5 | azure essence | `#9cc6ff` | `#3a7be0` |
| 6 | violet philtre | `#cbb0ff` | `#7d49e6` |
| 7 | magenta brew | `#ffaad8` | `#d64790` |

### Neon Arcade color tokens
- Backdrop: `radial-gradient(100% 60% at 50% 30%, rgba(120,40,200,0.35), transparent 70%), linear-gradient(#0c0718, #160a28 55%, #1d0c33)`
- Grid lines: magenta `#ff4cc6` (horizontal) + cyan `#34d6ff`/`rgba(80,220,255,0.45)` (vertical), 46×40px cells, `perspective(340px) rotateX(66deg)`
- Horizon line `#ff4cc6` with glow `0 0 14px #ff4cc6, 0 0 40px rgba(120,40,200,0.6)`
- "Sun": `radial-gradient(circle, rgba(255,170,80,0.55), rgba(255,80,200,0.25) 55%, transparent 70%)`
- Text fg `#dcecff` · title `#ffffff` · accent `#ff4cc6`
- Chip bg `rgba(120,40,200,0.20)` · border `rgba(255,80,200,0.4)` · fg `#ffd8f4`
- Primary CTA: `linear-gradient(90deg, #ff4cc6, #7a3cff 55%, #34d6ff)`, text `#0c0718`, shadow `0 0 18px rgba(255,76,198,0.6)`, radius 12px
- Scanline overlay + glowing-liquid drop-shadows on bottles (glow color = the top band's `a`).

**Neon liquid palette** (`a`/`b`): cherry `#ff9aa6`/`#d4123f` · amber
`#ffc371`/`#e06a00` · citron `#ffef8a`/`#e0a800` · absinthe `#86eea0`/`#129a48` ·
verde `#74efdd`/`#067e78` · cobalt `#86bcff`/`#1456d6` · violet `#c4a6ff`/`#6a2fd6` ·
rose `#ff9ad0`/`#cc1f73`.

### Shape / spacing
- Phone screen padding: home `60px 26px 42px`; game HUD `56px 22px 6px`.
- Border radius: CTA 14px (apo) / 12px (neon); chips & toggles 999px; HUD icon buttons 13–16px.
- Control-bar icon buttons: 50×50px, radius 16px. Back button 42×42px, radius 13px.
- Vessel render widths: home 78–96px; gameplay 70px.

---

## Screens / Views

### 1 · Apothecary — Home
- **Purpose:** Title screen; entry to play.
- **Layout:** Full-bleed `ApoBackdrop` behind a flex column, `space-between`,
  padding `60/26/42`. Top row (`space-between`): "EST. MMXXVI" kicker (left) +
  light/dark `ModeToggle` (right). Center: wordmark block. Lower: row of 3 hero
  bottles resting on the shelf. Bottom: full-width CTA + a row of 3 chips.
- **Components:**
  - **Kicker** "THE APOTHECARY" — Fraunces 13px, uppercase, tracking 0.42em, accent color.
  - **Wordmark** "Vessel" — Fraunces 70px, italic, 600, color = title token.
  - **Tagline** "Decant, settle, set in order." — Spectral 15.5px italic, sub color.
  - **Hero bottles** — 3 `ApoVessel`s (flask / round / vial), filled with 4 bands
    each, gently bobbing. Center one larger (96px vs 78px).
  - **CTA** "Begin the Decanting" — Fraunces 19px italic, gold gradient (see tokens).
  - **Chips** "Daily Draught" (active) · "Cabinet" · "Reverie" — Spectral 12px,
    pill, chip tokens; inactive at 0.72 opacity.

### 2 · Apothecary — Gameplay
- **Purpose:** The puzzle board.
- **Layout:** `ApoBackdrop` behind a flex column. **HUD** (top, `space-between`):
  back chevron (42×42 chip), centered title block, `ModeToggle` (right). **Tray**
  (flex-1): the bottles arranged in two rows (3 + 2). **Control bar** (bottom):
  Undo ↺ · Hint ✦ · Reset ⟳ as 50×50 chip buttons with captions.
- **HUD title:** "Tincture No. 7" (Fraunces 19px italic) + "AMBER CABINET" sub
  (Spectral 10.5px, uppercase, tracking 0.18em). A moves counter may replace the
  toggle slot in production — in the mock the toggle occupies the right slot.
- **Bottles:** `ApoVessel` shapes per slot `['round','flask','vial','flask','round']`,
  capacity 4, width 70px. Each bottle is a stack of color-index bands, bottom→top.

### 3 · Neon — Home  &  4 · Neon — Gameplay
- Same structural layout as Apothecary (wordmark/CTA/chips home; HUD/tray/controls
  game), restyled with the Neon tokens: dark synthwave backdrop with animated
  grid, magenta wordmark with glow, tube/tall bottles that emit colored light.
- **CTA** "PLAY" (Chakra Petch). HUD title "STAGE 07" / "NEON RUN".
- *Note:* Neon is currently the earlier, lower-detail bottle renderer
  (`vessel-bottle.jsx`); the Apothecary renderer (`apo-vessel.jsx`) is the more
  refined reference for glass/label/liquid construction.

---

## Interactions & Behavior
- **Light/dark toggle** (`ModeToggle`): sun/moon pill, animated knob slide
  (`left .3s cubic-bezier(.34,1.4,.5,1)`); swaps every Apothecary token + bottle
  shading. Lives top-right of Home and Game.
- **Idle bottle bob:** ~6–7px vertical, 4s ease-in-out, staggered per bottle.
- **The auto-playing solve loop in the mock is demo-only** — production should be
  interactive (tap source bottle → tap target → pour). The loop exists purely to
  showcase the pour visuals.
- **Move legality** (from the original game, worth reusing): you may pour the top
  run of one bottle onto another only if the target is empty or its top color
  matches, and has capacity. A bottle is "done" when full of a single color.

---

## Effects & Physics — Claude Code's responsibility
Re-implement these in the engine; the HTML is intent only.

1. **Liquid surface** — real meniscus (curves up at glass walls), a surface that
   waves and *settles* with damping, not a looping sine. Intended idle: subtle.
   On lift/carry: slosh proportional to acceleration. On tilt: surface stays
   gravity-level while the glass rotates.
2. **Bubbles & fizz** — particles rising from the base, sway, pop at surface;
   density per liquid type. Vapor/steam wisps from an uncorked mouth.
3. **Pour** — cork pops; bottle tilts; an **arcing stream** leaves the lip
   following gravity + tilt angle; volume transfers band-by-band (conserved);
   droplets fall; **ripple + splash** on the receiving surface; receiving level
   rises smoothly.
4. **3D / lighting** — real depth: refractive glass, depth-sorted scene,
   specular highlights that track a light, soft contact shadows on the shelf.
   The mock fakes this with CSS parallax + gradients only.
5. **Neon "sort to the beat" mode** (requested, not built) — quantize pours to a
   music track; pulse glow/grid on the beat; combo feedback.

---

## Files
HTML/JSX design references included in `files/` (and live in the project root):
- `index.html` — app shell: **all backdrop CSS + keyframes** (apothecary light/dark
  shelf, neon grid, liquid/atmosphere keyframes) live here. Best CSS reference.
- `app.jsx` — theme token objects (`APO`, `NEON`), screen routing, canvas layout.
- `apo-vessel.jsx` — **the refined glassware**: shape geometry (round/flask/vial),
  cork, parchment label, glass gradients/sheen, liquid bands, bubbles. Best
  reference for bottle construction + color usage.
- `apo-screens.jsx` — `ApoHome`, `ApoGame`, `ApoBackdrop`, `ModeToggle`.
- `apo-scene.jsx` — gameplay tray + the (faked) pour-loop choreography & timings.
- `vessel-bottle.jsx`, `vessel-scene.jsx`, `vessel-home.jsx`, `vessel-game.jsx` —
  the Neon renderer + screens.
- `source/bottlesort-original.html` — the **original game** (logic, level format,
  win detection) for gameplay rules reference.
- `ios-frame.jsx`, `design-canvas.jsx` — presentation scaffolding only; **not**
  part of the design, do not port.

Open `index.html` to view all four screens side-by-side.
