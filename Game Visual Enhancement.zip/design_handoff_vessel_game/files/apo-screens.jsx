// apo-screens.jsx — apothecary Home & Game screens with a light/dark shelf
// toggle. Uses the .bg-apo CSS furniture + ApoVessel + ApoScene.
// Exports window.ApoHome, window.ApoGame.

function ApoBackdrop({ dark }) {
  return (
    <div className={'bg-apo ' + (dark ? 'dark' : 'light')}>
      <div className="planks" />
      <div className="rays" />
      <div className="dust" />
      <div className="glow" />
      <div className="shelf" />
    </div>
  );
}

function apoInk(dark) {
  return dark
    ? { fg: '#f1e2cd', title: '#f8ecd6', sub: 'rgba(241,226,205,0.62)', accent: '#f0c074',
        chipBg: 'rgba(255,226,180,0.08)', chipBorder: '1px solid rgba(255,214,156,0.30)', chipFg: '#f0dcc0' }
    : { fg: '#5a3a1c', title: '#3a2410', sub: 'rgba(90,58,28,0.6)', accent: '#b9742a',
        chipBg: 'rgba(120,78,38,0.07)', chipBorder: '1px solid rgba(120,78,38,0.22)', chipFg: '#5a3a1c' };
}

// ── sun/moon mode toggle ──
function ModeToggle({ dark, onToggle }) {
  const ink = apoInk(dark);
  return (
    <button onClick={onToggle} style={{
      display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
      padding: '8px 12px', borderRadius: 999, border: ink.chipBorder,
      background: ink.chipBg, color: ink.chipFg, fontSize: 15, lineHeight: 1,
    }}>
      <span style={{ opacity: dark ? 0.4 : 1, transition: 'opacity .3s' }}>☀</span>
      <span style={{
        width: 26, height: 15, borderRadius: 999, position: 'relative',
        background: dark ? 'rgba(255,210,150,0.25)' : 'rgba(120,78,38,0.2)',
        transition: 'background .3s',
      }}>
        <span style={{
          position: 'absolute', top: 1.5, left: dark ? 12.5 : 1.5, width: 12, height: 12,
          borderRadius: '50%', background: dark ? '#f0c074' : '#7a542c',
          transition: 'left .3s cubic-bezier(.34,1.4,.5,1)',
        }} />
      </span>
      <span style={{ opacity: dark ? 1 : 0.4, transition: 'opacity .3s' }}>☾</span>
    </button>
  );
}

function ApoHome({ theme = {} }) {
  const [dark, setDark] = React.useState(false);
  const ink = apoInk(dark);
  const C = window.APO_COLORS;
  const hero = [
    { shape: 'flask', bands: [C[1], C[3], C[5], C[2]] },
    { shape: 'round', bands: [C[6], C[0], C[3], C[4]] },
    { shape: 'vial',  bands: [C[4], C[7], C[1], C[5]] },
  ];
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <ApoBackdrop dark={dark} />
      <div style={{
        position: 'absolute', inset: 0, zIndex: 2, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'space-between',
        padding: '60px 26px 42px', boxSizing: 'border-box', color: ink.fg,
      }}>
        {/* top row: kicker + toggle */}
        <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div style={{ fontFamily: theme.headFont, fontSize: 12, letterSpacing: '0.4em',
            textTransform: 'uppercase', color: ink.accent, marginTop: 8 }}>Est. MMXXVI</div>
          <ModeToggle dark={dark} onToggle={() => setDark(d => !d)} />
        </div>

        {/* wordmark */}
        <div style={{ textAlign: 'center', marginTop: -12 }}>
          <div style={{ fontFamily: theme.headFont, fontSize: 13, letterSpacing: '0.42em',
            textTransform: 'uppercase', color: ink.accent, opacity: 0.85, marginBottom: 8 }}>The Apothecary</div>
          <h1 style={{ fontFamily: theme.headFont, fontSize: 70, lineHeight: 0.9, margin: 0,
            fontWeight: 600, fontStyle: 'italic', letterSpacing: '-0.02em', color: ink.title }}>Vessel</h1>
          <p style={{ fontFamily: theme.bodyFont, fontSize: 15.5, margin: '12px 0 0',
            color: ink.sub, fontStyle: 'italic' }}>Decant, settle, set in order.</p>
        </div>

        {/* hero bottles resting on the shelf */}
        <div style={{ display: 'flex', gap: 6, alignItems: 'flex-end', marginBottom: 6 }}>
          {hero.map((h, i) => (
            <div key={i} style={{ ['--r']: '0deg',
              animation: `apoBob 4.${i + 2}s ease-in-out ${i * 0.4}s infinite` }}>
              <ApoVessel shape={h.shape} bands={h.bands} capacity={4}
                width={i === 1 ? 96 : 78} dark={dark} showLabel={true} />
            </div>
          ))}
        </div>

        {/* CTA + chips */}
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 16, alignItems: 'center' }}>
          <button style={{
            fontFamily: theme.headFont, fontSize: 19, fontStyle: 'italic', letterSpacing: '0.01em',
            padding: '17px 0', width: '100%', borderRadius: 14, border: 'none', cursor: 'pointer',
            color: '#3a2410', fontWeight: 600,
            background: 'linear-gradient(#f3c97f, #d18b34)',
            boxShadow: '0 8px 20px rgba(150,95,35,0.4), inset 0 1px 0 rgba(255,255,255,0.6)',
          }}>Begin the Decanting</button>
          <div style={{ display: 'flex', gap: 10 }}>
            {['Daily Draught', 'Cabinet', 'Reverie'].map((c, i) => (
              <div key={c} style={{ fontFamily: theme.bodyFont, fontSize: 12, letterSpacing: '0.04em',
                padding: '9px 15px', borderRadius: 999, border: ink.chipBorder,
                background: ink.chipBg, color: ink.chipFg, opacity: i === 0 ? 1 : 0.72 }}>{c}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ApoGame({ theme = {} }) {
  const [dark, setDark] = React.useState(false);
  const ink = apoInk(dark);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', color: ink.fg }}>
      <ApoBackdrop dark={dark} />
      <div style={{ position: 'absolute', inset: 0, zIndex: 2, display: 'flex', flexDirection: 'column' }}>
        {/* HUD */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '56px 22px 6px' }}>
          <div style={{ width: 42, height: 42, borderRadius: 13, display: 'grid', placeItems: 'center',
            background: ink.chipBg, border: ink.chipBorder, color: ink.chipFg, fontSize: 18 }}>‹</div>
          <div style={{ textAlign: 'center', flex: 1, minWidth: 0, padding: '0 10px' }}>
            <div style={{ fontFamily: theme.headFont, fontSize: 19, fontWeight: 600, fontStyle: 'italic',
              color: ink.title, whiteSpace: 'nowrap' }}>Tincture No. 7</div>
            <div style={{ fontFamily: theme.bodyFont, fontSize: 10.5, color: ink.sub,
              letterSpacing: '0.18em', textTransform: 'uppercase', marginTop: 2, whiteSpace: 'nowrap' }}>Amber Cabinet</div>
          </div>
          <ModeToggle dark={dark} onToggle={() => setDark(d => !d)} />
        </div>

        {/* the animated tray */}
        <div style={{ flex: 1, minHeight: 0 }}>
          <ApoScene theme={theme} dark={dark} />
        </div>

        {/* control bar */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 30, padding: '4px 0 30px' }}>
          {[['↺', 'Undo'], ['✦', 'Hint'], ['⟳', 'Reset']].map(([icon, label]) => (
            <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              <div style={{ width: 50, height: 50, borderRadius: 16, display: 'grid', placeItems: 'center',
                background: ink.chipBg, border: ink.chipBorder, color: ink.chipFg, fontSize: 21 }}>{icon}</div>
              <span style={{ fontFamily: theme.bodyFont, fontSize: 10.5, letterSpacing: '0.08em',
                textTransform: 'uppercase', color: ink.sub }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ApoHome, ApoGame, ApoBackdrop });