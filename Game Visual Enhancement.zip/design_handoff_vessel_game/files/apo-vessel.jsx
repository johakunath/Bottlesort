// apo-vessel.jsx — apothecary glassware: corked potion bottles & flasks with
// parchment labels, wax, refractive glass, and physically-styled liquid
// (wavy sloshing surface + rising bubbles + meniscus). Exports window.ApoVessel.

const APO_SHAPES = {
  // bulbous round-bottom potion bottle
  round: {
    vbH: 270, w: 100,
    interior: 'M43,66 L43,94 C43,106 18,114 18,170 C18,228 36,252 50,252 C64,252 82,228 82,170 C82,114 57,106 57,94 L57,66 Z',
    outline:  'M40,40 L40,93 C40,107 15,114 15,170 C15,231 35,256 50,256 C65,256 85,231 85,170 C85,114 60,107 60,93 L60,40',
    neckX1: 40, neckX2: 60, neckTop: 40,
    T: 98, B: 248, mouthY: 40,
    cork: { x: 36, y: 18, w: 28, h: 26, r: 7 },
    label: { x: 27, y: 158, w: 46, h: 60, rot: -1.5 },
    gloss: [
      { x: 26, y: 120, w: 9, h: 96, rx: 4.5, o: 0.55 },
      { x: 70, y: 132, w: 4, h: 76, rx: 2, o: 0.3 },
    ],
  },
  // erlenmeyer flask
  flask: {
    vbH: 270, w: 100,
    interior: 'M44,60 L44,120 L21,236 C19,247 23,252 33,252 L67,252 C77,252 81,247 79,236 L56,120 L56,60 Z',
    outline:  'M41,36 L41,119 L18,236 C15,249 21,256 33,256 L67,256 C79,256 85,249 82,236 L59,119 L59,36',
    neckX1: 41, neckX2: 59, neckTop: 36,
    T: 128, B: 248, mouthY: 36,
    cork: { x: 37, y: 14, w: 26, h: 24, r: 6 },
    label: { x: 30, y: 182, w: 40, h: 46, rot: 1 },
    gloss: [
      { x: 30, y: 150, w: 8, h: 84, rx: 4, o: 0.5 },
      { x: 64, y: 162, w: 3.5, h: 66, rx: 1.8, o: 0.28 },
    ],
  },
  // tall slim corked vial
  vial: {
    vbH: 290, w: 100,
    interior: 'M41,46 L41,256 C41,266 45,270 50,270 C55,270 59,266 59,256 L59,46 Z',
    outline:  'M38,22 L38,256 C38,268 44,274 50,274 C56,274 62,268 62,256 L62,22',
    neckX1: 38, neckX2: 62, neckTop: 22,
    T: 56, B: 262, mouthY: 22,
    cork: { x: 35, y: 2, w: 30, h: 22, r: 6 },
    label: { x: 36, y: 150, w: 28, h: 78, rot: 0 },
    gloss: [
      { x: 30, y: 70, w: 7, h: 170, rx: 3.5, o: 0.5 },
      { x: 61, y: 84, w: 3, h: 150, rx: 1.5, o: 0.28 },
    ],
  },
};

// jewel-but-luminous liquid palette tuned for a bright daylit shelf
const APO_COLORS = [
  { a: '#ff8fa0', b: '#e23b5d', name: 'rose elixir' },
  { a: '#ffce7a', b: '#ef8a1e', name: 'amber tincture' },
  { a: '#fff39b', b: '#ecc02c', name: 'citron cordial' },
  { a: '#9ef0a6', b: '#37b35a', name: 'verdant draught' },
  { a: '#8ff0e2', b: '#19a89a', name: 'aqua vitae' },
  { a: '#9cc6ff', b: '#3a7be0', name: 'azure essence' },
  { a: '#cbb0ff', b: '#7d49e6', name: 'violet philtre' },
  { a: '#ffaad8', b: '#d64790', name: 'magenta brew' },
];

// build a sine-wave top edge across the full width, closed into a fillable
// area down to y=420. Sampled as a smooth quadratic path.
function wavePath(yTop, amp, phase, k = 0.95) {
  const L = -25, R = 125, steps = 9, dx = (R - L) / steps;
  let d = `M ${L} ${(yTop + amp * Math.sin(phase)).toFixed(2)}`;
  for (let i = 1; i <= steps; i++) {
    const x = L + dx * i;
    const y = yTop + amp * Math.sin(phase + i * k);
    const xc = x - dx / 2;
    const yc = yTop + amp * Math.sin(phase + (i - 0.5) * k);
    d += ` Q ${xc.toFixed(2)} ${yc.toFixed(2)} ${x.toFixed(2)} ${y.toFixed(2)}`;
  }
  d += ` L ${R} 460 L ${L} 460 Z`;
  return d;
}
function waveValues(yTop, amp) {
  // 4 phases → seamless SMIL loop
  const ph = [0, Math.PI / 2, Math.PI, Math.PI * 1.5, Math.PI * 2];
  return ph.map(p => wavePath(yTop, amp, p)).join(';');
}

let _auid = 0;

function ApoVessel({
  shape = 'round', bands = [], capacity = 4,
  tilt = 0, wobble = 0, width = 72,
  bubbling = true, corkLift = 0, showLabel = true,
  selected = false, dim = false, dark = false, style = {},
}) {
  const S = APO_SHAPES[shape] || APO_SHAPES.round;
  const idRef = React.useRef(null);
  if (!idRef.current) idRef.current = 'av' + _auid++;
  const uid = idRef.current;

  const cx = 50, cy = S.vbH / 2;
  const cellH = (S.B - S.T) / capacity;
  const aspect = S.vbH / S.w;
  const liquidRot = -tilt + wobble;           // keep surface gravity-level
  const fillTopY = S.B - bands.length * cellH; // current liquid surface
  const topBand = bands[bands.length - 1];
  const topA = topBand ? (typeof topBand === 'string' ? topBand : topBand.a) : '#fff';

  // glass tint shifts subtly between light/dark shelf
  const glassEdge = dark ? 'rgba(150,180,210,0.16)' : 'rgba(120,150,190,0.10)';
  const rimColor = dark ? 'rgba(225,240,255,0.85)' : 'rgba(255,255,255,0.95)';

  // deterministic bubble set
  const bubbles = React.useMemo(() => {
    const arr = [];
    const n = shape === 'vial' ? 5 : 7;
    for (let i = 0; i < n; i++) {
      arr.push({
        x: 32 + Math.random() * 36,
        r: 0.8 + Math.random() * 1.7,
        dur: 2.4 + Math.random() * 2.6,
        delay: -Math.random() * 4,
        rise: 30 + Math.random() * 40,
      });
    }
    return arr;
  }, [shape]);

  return (
    <svg
      viewBox={`0 0 ${S.w} ${S.vbH}`}
      width={width}
      height={width * aspect}
      style={{
        overflow: 'visible', display: 'block',
        transform: `rotate(${tilt}deg)`,
        transformOrigin: `${cx}px ${cy}px`,
        transition: selected
          ? 'transform .2s cubic-bezier(.34,1.4,.5,1)'
          : 'transform .4s cubic-bezier(.4,0,.2,1)',
        filter: dark
          ? 'drop-shadow(0 8px 14px rgba(0,0,0,0.5))'
          : 'drop-shadow(0 10px 16px rgba(90,60,30,0.28))',
        opacity: dim ? 0.45 : 1,
        ...style,
      }}
    >
      <defs>
        <clipPath id={uid + 'clip'}><path d={S.interior} /></clipPath>
        <linearGradient id={uid + 'glass'} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="rgba(255,255,255,0.30)" />
          <stop offset="0.32" stopColor={glassEdge} />
          <stop offset="0.7" stopColor="rgba(40,55,80,0.10)" />
          <stop offset="1" stopColor="rgba(255,255,255,0.16)" />
        </linearGradient>
        <radialGradient id={uid + 'sheen'} cx="0.35" cy="0.25" r="0.8">
          <stop offset="0" stopColor="rgba(255,255,255,0.5)" />
          <stop offset="0.4" stopColor="rgba(255,255,255,0)" />
        </radialGradient>
        <linearGradient id={uid + 'inner'} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="rgba(0,0,0,0.26)" />
          <stop offset="0.2" stopColor="rgba(0,0,0,0)" />
          <stop offset="0.82" stopColor="rgba(0,0,0,0)" />
          <stop offset="1" stopColor="rgba(0,0,0,0.32)" />
        </linearGradient>
      </defs>

      {/* glass body */}
      <path d={S.interior} fill={`url(#${uid}glass)`} />

      {/* liquid — clipped to interior, counter-rotated to stay level */}
      <g clipPath={`url(#${uid}clip)`}>
        <g transform={`rotate(${liquidRot} ${cx} ${cy})`}>
          {bands.map((band, i) => {
            const a = typeof band === 'string' ? band : band.a;
            const b = typeof band === 'string' ? band : band.b;
            const yTop = S.B - (i + 1) * cellH;
            const isTop = i === bands.length - 1;
            const lg = uid + 'L' + i;
            return (
              <g key={i}>
                <defs>
                  <linearGradient id={lg} x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0" stopColor={b} />
                    <stop offset="0.45" stopColor={a} />
                    <stop offset="1" stopColor={b} />
                  </linearGradient>
                </defs>
                {isTop ? (
                  <path d={wavePath(yTop, 2.2, 0)} fill={`url(#${lg})`}>
                    <animate attributeName="d" dur="3.6s" repeatCount="indefinite"
                      values={waveValues(yTop, 2.2)} calcMode="spline"
                      keyTimes="0;0.25;0.5;0.75;1"
                      keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1" />
                  </path>
                ) : (
                  <rect x={-25} y={yTop} width={150} height={cellH + 120} fill={`url(#${lg})`} />
                )}
              </g>
            );
          })}

          {/* rising bubbles in the filled region */}
          {bubbling && bands.length > 0 && bubbles.map((bb, i) => (
            <circle key={i} cx={bb.x} cy={S.B - 6} r={bb.r}
              fill="rgba(255,255,255,0.7)"
              style={{
                transformBox: 'fill-box', transformOrigin: 'center',
                animation: `apoBubble ${bb.dur}s ease-in ${bb.delay}s infinite`,
                ['--rise']: `-${(bb.rise + (bands.length * cellH) * 0.4).toFixed(0)}px`,
              }} />
          ))}
        </g>

        {/* curvature shadow + glossy sheen */}
        <rect x="0" y="0" width={S.w} height={S.vbH} fill={`url(#${uid}inner)`} />
        <path d={S.interior} fill={`url(#${uid}sheen)`} />
      </g>

      {/* parchment label */}
      {showLabel && (() => {
        const L = S.label;
        return (
          <g transform={`rotate(${L.rot} ${L.x + L.w / 2} ${L.y + L.h / 2})`}>
            <rect x={L.x} y={L.y} width={L.w} height={L.h} rx="3"
              fill={dark ? '#e8dcc2' : '#f7efdc'} stroke="rgba(120,90,50,0.35)" strokeWidth="0.8" />
            <rect x={L.x} y={L.y} width={L.w} height={L.h} rx="3"
              fill="rgba(150,110,60,0.10)" />
            {/* ink lines */}
            <line x1={L.x + 7} y1={L.y + 13} x2={L.x + L.w - 7} y2={L.y + 13}
              stroke="rgba(80,55,30,0.6)" strokeWidth="1.6" strokeLinecap="round" />
            {[22, 30, 38].map((dy, k) => (
              <line key={k} x1={L.x + 7} y1={L.y + dy} x2={L.x + L.w - (k === 2 ? 16 : 7)} y2={L.y + dy}
                stroke="rgba(90,65,40,0.45)" strokeWidth="1" strokeLinecap="round" />
            ))}
          </g>
        );
      })()}

      {/* glass outline + rim */}
      <path d={S.outline} fill="none" stroke={rimColor} strokeWidth="2.4"
        strokeLinecap="round" strokeLinejoin="round" opacity="0.92" />

      {/* specular streaks */}
      {S.gloss.map((g, i) => (
        <rect key={i} x={g.x} y={g.y} width={g.w} height={g.h} rx={g.rx}
          fill="#fff" opacity={g.o} />
      ))}

      {/* cork stopper (lifts during pour) */}
      {(() => {
        const c = S.cork;
        return (
          <g transform={`translate(0 ${-corkLift}) rotate(${corkLift ? 12 : 0} ${c.x + c.w / 2} ${c.y})`}
             style={{ transition: 'transform .35s ease' }}>
            <rect x={c.x} y={c.y} width={c.w} height={c.h} rx={c.r}
              fill="#c08a4e" stroke="#8a5e2c" strokeWidth="1.2" />
            <rect x={c.x} y={c.y} width={c.w} height={c.h * 0.4} rx={c.r}
              fill="rgba(255,235,200,0.35)" />
            {/* cork stipple */}
            {[0.3, 0.55, 0.75].map((f, k) => (
              <line key={k} x1={c.x + 3} y1={c.y + c.h * f} x2={c.x + c.w - 3} y2={c.y + c.h * f}
                stroke="rgba(110,70,30,0.35)" strokeWidth="0.8" />
            ))}
          </g>
        );
      })()}
    </svg>
  );
}

Object.assign(window, { ApoVessel, APO_SHAPES, APO_COLORS });