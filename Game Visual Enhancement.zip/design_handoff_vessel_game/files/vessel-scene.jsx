// vessel-scene.jsx — animated gameplay mockup. Auto-plays a believable sort:
// lifts a source vessel, carries it over a target, tilts & pours (liquid
// sloshes via a sine wobble), top bands transfer, vessel returns. Loops.
// Parallax: the whole tray reacts to device-orientation / pointer.
// Exports window.VesselScene (props: theme).

const LEVELS = [
  // each bottle = array of color indices, bottom -> top (cap 4)
  [ [0,1,2,0], [1,2,0,1], [2,0,1,2], [], [] ],
];

// A solvable scripted move list for LEVELS[0], as [fromIdx, toIdx].
// Played on a loop; we reset to the start state when finished.
function cloneLevel(l) { return l.map(b => b.slice()); }

function topRun(b) {
  if (!b.length) return { color: -1, n: 0 };
  const c = b[b.length - 1]; let n = 0;
  for (let i = b.length - 1; i >= 0 && b[i] === c; i--) n++;
  return { color: c, n };
}

function legalMoves(bottles, cap) {
  const moves = [];
  for (let i = 0; i < bottles.length; i++) {
    const from = bottles[i];
    if (!from.length) continue;
    const tr = topRun(from);
    if (tr.n === from.length && new Set(from).size === 1) continue; // already done
    for (let j = 0; j < bottles.length; j++) {
      if (i === j) continue;
      const to = bottles[j];
      if (to.length >= cap) continue;
      if (to.length === 0 || to[to.length - 1] === tr.color) {
        if (to.length < cap) moves.push([i, j, tr]);
      }
    }
  }
  return moves;
}

// pick a move that makes progress; prefer pouring onto a matching non-empty
// stack, then onto empty. Light heuristic — good enough for a looping demo.
function pickMove(bottles, cap) {
  const ms = legalMoves(bottles, cap);
  if (!ms.length) return null;
  ms.sort((a, b) => {
    const an = bottles[a[1]].length, bn = bottles[b[1]].length;
    return (bn > 0) - (an > 0) || bn - an;
  });
  return ms[0];
}

const CAP = 4;
const EASE = 'cubic-bezier(.45,.05,.3,1)';

// curved tapering pour stream + falling droplets, anchored on the receiver.
function PourStream({ color, side, neon }) {
  const sx = 40 + side * 24;          // stream origin x (under the tilted lip)
  const d = `M ${sx} 2 C ${sx} 40, 40 60, 40 118`;
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '-86%', width: 80, height: 150,
      transform: 'translateX(-50%)', pointerEvents: 'none', zIndex: 40,
      animation: 'vsStreamIn .26s ease-out',
    }}>
      <svg viewBox="0 0 80 150" width="80" height="150" style={{ overflow: 'visible' }}>
        <defs>
          <linearGradient id="vsStreamG" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={color.a} />
            <stop offset="1" stopColor={color.b} />
          </linearGradient>
        </defs>
        <path d={d} fill="none" stroke="url(#vsStreamG)" strokeWidth="5.5" strokeLinecap="round"
          style={{ filter: neon ? `drop-shadow(0 0 5px ${color.a})` : 'none' }} />
        <path d={d} fill="none" stroke={color.hi || '#fff'} strokeWidth="1.6" strokeLinecap="round" opacity="0.7" />
        {[0, 1, 2].map(i => (
          <circle key={i} cx="40" cy="110" r={1.6 + i * 0.5} fill={color.a}
            style={{ animation: `vsDrop .5s ${i * 0.16}s ease-in infinite`,
              filter: neon ? `drop-shadow(0 0 4px ${color.a})` : 'none' }} />
        ))}
      </svg>
    </div>
  );
}

function VesselScene({ theme = {} }) {
  const t = theme;
  const initial = React.useMemo(() => cloneLevel(LEVELS[0]), []);
  const [bottles, setBottles] = React.useState(initial);
  const [anim, setAnim] = React.useState(null); // {from,to,phase,dx,dy,lift,tilt,color}
  const [wobble, setWobble] = React.useState(0);
  const [agit, setAgit] = React.useState({});   // per-bottle slosh intensity 0..1
  const [parallax, setParallax] = React.useState({ x: 0, y: 0 });
  const [solvedPulse, setSolvedPulse] = React.useState(false);

  const slotRefs = React.useRef([]);
  const trayRef = React.useRef(null);
  const timers = React.useRef([]);
  const after = (ms, fn) => { const id = setTimeout(fn, ms); timers.current.push(id); };
  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };

  // ── parallax from pointer (and device tilt if granted) ──
  React.useEffect(() => {
    const stage = trayRef.current?.closest('[data-vessel-stage]') || window;
    const onMove = (e) => {
      const w = window.innerWidth, h = window.innerHeight;
      const px = (e.clientX / w - 0.5) * 2, py = (e.clientY / h - 0.5) * 2;
      setParallax({ x: px, y: py });
    };
    const onOrient = (e) => {
      if (e.gamma == null) return;
      setParallax({ x: Math.max(-1, Math.min(1, e.gamma / 30)),
                    y: Math.max(-1, Math.min(1, (e.beta - 45) / 30)) });
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('deviceorientation', onOrient);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('deviceorientation', onOrient);
    };
  }, []);

  // ── the pour loop ──
  React.useEffect(() => {
    let alive = true;
    const step = (state) => {
      if (!alive) return;
      const mv = pickMove(state, CAP);
      if (!mv) {
        // solved → celebrate, reset
        setSolvedPulse(true);
        after(1400, () => setSolvedPulse(false));
        after(2200, () => { setBottles(cloneLevel(LEVELS[0])); after(700, () => step(cloneLevel(LEVELS[0]))); });
        return;
      }
      const [fi, ti, tr] = mv;
      const moveN = Math.min(tr.n, CAP - state[ti].length);
      const color = tr.color;

      // geometry: where to carry the source so its mouth sits over target
      const sEl = slotRefs.current[fi], tEl = slotRefs.current[ti];
      let dx = 0, dy = -120, side = ti > fi ? 1 : -1, tilt = 0;
      if (sEl && tEl) {
        const sr = sEl.getBoundingClientRect(), trc = tEl.getBoundingClientRect();
        side = trc.left >= sr.left ? 1 : -1;
        dx = (trc.left - sr.left) + side * -6;
        dy = (trc.top - sr.top) - sr.height * 0.62;
        tilt = side * 58;
      }

      // phase 1: lift
      setAnim({ from: fi, to: ti, phase: 'lift', dx: 0, dy: -34, tilt: 0, color, side });
      // phase 2: carry
      after(420, () => setAnim(a => a && { ...a, phase: 'carry', dx, dy, tilt: tilt * 0.5 }));
      // phase 3: pour (tilt fully, stream on)
      after(900, () => setAnim(a => a && { ...a, phase: 'pour', tilt }));
      // pour begins → source sloshes hard
      after(900, () => setAgit({ [fi]: 0.95 }));
      // transfer liquid mid-pour → target receives, both agitated
      after(1150, () => {
        if (!alive) return;
        setBottles(prev => {
          const nx = prev.map(b => b.slice());
          for (let k = 0; k < moveN; k++) { nx[fi].pop(); nx[ti].push(color); }
          return nx;
        });
        setAgit({ [fi]: 0.6, [ti]: 1.0 });
      });
      // phase 4: untilt
      after(1750, () => { setAnim(a => a && { ...a, phase: 'carry', tilt: tilt * 0.4 }); setAgit({ [fi]: 0.3, [ti]: 0.6 }); });
      // phase 5: return
      after(1950, () => setAnim(a => a && { ...a, phase: 'return', dx: 0, dy: -34, tilt: 0 }));
      after(2150, () => setAgit({ [ti]: 0.3 }));
      after(2350, () => setAnim(null));
      after(2600, () => setAgit({}));
      // next move
      after(2750, () => {
        setBottles(cur => { step(cur); return cur; });
      });
    };
    after(900, () => step(cloneLevel(LEVELS[0])));
    return () => { alive = false; clearTimers(); };
  }, []);

  // ── slosh wobble while moving/pouring ──
  React.useEffect(() => {
    if (!anim || (anim.phase !== 'carry' && anim.phase !== 'pour' && anim.phase !== 'lift')) {
      setWobble(0); return;
    }
    let raf, t0 = performance.now();
    const amp = anim.phase === 'pour' ? 5 : 8;
    const tick = (now) => {
      const e = (now - t0) / 1000;
      setWobble(Math.sin(e * 7) * amp * Math.exp(-e * 0.4));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [anim?.phase]);

  // map a bottle's color indices to gradient bands
  const bandsOf = (b) => b.map(ci => VESSEL_COLORS[ci % VESSEL_COLORS.length]);
  const glowOf = (b) => {
    if (!t.neon || !b.length) return null;
    return VESSEL_COLORS[b[b.length - 1] % VESSEL_COLORS.length].a;
  };

  const rows = [[0, 1, 2], [3, 4]];
  const px = parallax.x, py = parallax.y;

  return (
    <div ref={trayRef} data-vessel-stage style={{
      width: '100%', height: '100%', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      perspective: '900px', perspectiveOrigin: '50% 40%',
    }}>
      <div style={{
        display: 'flex', flexDirection: 'column', gap: 'clamp(16px,5vh,40px)',
        alignItems: 'center',
        transform: `rotateX(${(-py * 5).toFixed(2)}deg) rotateY(${(px * 7).toFixed(2)}deg) translate(${(px * 10).toFixed(1)}px, ${(py * 6).toFixed(1)}px)`,
        transformStyle: 'preserve-3d',
        transition: 'transform .25s ease-out',
      }}>
        {rows.map((row, ri) => (
          <div key={ri} style={{ display: 'flex', gap: 'clamp(14px,5vw,30px)', alignItems: 'flex-end' }}>
            {row.map((i) => {
              const b = bottles[i] || [];
              const isSrc = anim && anim.from === i;
              const isTgt = anim && anim.to === i;
              const lift = isSrc ? { dx: anim.dx, dy: anim.dy, tilt: anim.tilt } : { dx: 0, dy: 0, tilt: 0 };
              const pouring = isSrc && anim.phase === 'pour';
              const depth = ri * -22; // back row pushed away for 3D
              return (
                <div key={i} ref={el => slotRefs.current[i] = el}
                  style={{ position: 'relative', transform: `translateZ(${depth}px)`, transformStyle: 'preserve-3d' }}>
                  {/* pedestal shadow */}
                  <div style={{
                    position: 'absolute', left: '50%', bottom: -10, width: '70%', height: 14,
                    transform: `translateX(-50%) scale(${isSrc ? 0.6 : 1})`,
                    background: 'radial-gradient(ellipse, rgba(0,0,0,0.45), transparent 70%)',
                    filter: 'blur(3px)', opacity: isSrc ? 0.3 : 0.6,
                    transition: 'all .4s ease',
                  }} />
                  <div style={{
                    transform: `translate(${lift.dx}px, ${lift.dy}px) scale(${isSrc ? 1.04 : 1})`,
                    transition: `transform ${anim && (anim.phase === 'carry' || anim.phase === 'return') ? '0.46s' : '0.4s'} ${EASE}`,
                    zIndex: isSrc ? 50 : 1, position: 'relative', willChange: 'transform',
                  }}>
                    <Vessel
                      shape={t.shape || 'apothecary'}
                      bands={bandsOf(b)}
                      capacity={CAP}
                      tilt={lift.tilt}
                      wobble={isSrc ? wobble : 0}
                      agitation={agit[i] || 0}
                      width={t.vesselWidth || 64}
                      theme={{ glassTint: t.glassTint, rim: t.rim, accent: t.accent }}
                      glow={glowOf(b)}
                      cork={false}
                      selected={isSrc}
                    />
                  </div>
                  {/* curved pour stream falls into the receiving vessel */}
                  {isTgt && anim.phase === 'pour' && (
                    <PourStream color={VESSEL_COLORS[anim.color]} side={anim.side} neon={t.neon} />
                  )}
                  {/* splash highlight on the receiving vessel */}
                  {isTgt && anim.phase === 'pour' && (
                    <div style={{
                      position: 'absolute', left: '50%', top: '34%', width: 10, height: 10,
                      transform: 'translateX(-50%)', borderRadius: '50%',
                      background: VESSEL_COLORS[anim.color].a, opacity: 0.8,
                      animation: 'vsSplash .5s ease-out',
                    }} />
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      {solvedPulse && (
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: t.headFont || 'serif', fontSize: 30, letterSpacing: '0.06em',
          color: t.accent || '#fff', textShadow: t.neon ? `0 0 16px ${t.accent}` : '0 2px 6px rgba(0,0,0,0.4)',
          animation: 'vsSolved 1.4s ease-out',
        }}>{t.solvedText || 'Sorted'}</div>
      )}
    </div>
  );
}

Object.assign(window, { VesselScene });
