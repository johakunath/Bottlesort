// vessel-bottle.jsx — apothecary glass vessels with LIVING liquid.
// A shared rAF clock drives a wavy sloshing surface + rising bubbles + caustic
// shimmer, mutated directly on the DOM (no React re-render per frame). Bottles
// carry apothecary furniture: cork stoppers, parchment labels, wax, twine.
// Exports: window.Vessel, window.VESSEL_COLORS, window.VESSEL_SHAPES, window.vesselClock

// ── shared animation clock ───────────────────────────────────────────────
const vesselClock = (() => {
  const subs = new Set();
  let raf = null, t0 = performance.now();
  const loop = (now) => {
    const t = (now - t0) / 1000;
    subs.forEach(fn => { try { fn(t); } catch (e) {} });
    raf = requestAnimationFrame(loop);
  };
  return {
    sub(fn) {
      subs.add(fn);
      if (raf == null) raf = requestAnimationFrame(loop);
      return () => { subs.delete(fn); if (!subs.size && raf != null) { cancelAnimationFrame(raf); raf = null; } };
    },
  };
})();

// ── apothecary shapes (viewBox width 100) ────────────────────────────────
// interior = liquid clip; outline = full glass; T..B = liquid fill band range.
const SHAPES = {
  // round-shouldered corked chemist bottle
  apothecary: {
    vbH: 252, w: 100,
    interior: 'M25,86 L25,198 Q25,228 50,228 Q75,228 75,198 L75,86 Q75,80 69,80 L31,80 Q25,80 25,86 Z',
    outline: 'M41,26 L41,46 Q41,55 33,61 Q21,71 21,92 L21,198 Q21,232 50,232 Q79,232 79,198 L79,92 Q79,71 67,61 Q59,55 59,46 L59,26',
    rim: { cx: 50, cy: 26, rx: 11, ry: 3 },
    cork: { x: 39.5, y: 8, w: 21, h: 20, top: 13.5, taper: 2.4 },
    label: { x: 28, y: 120, w: 44, h: 58, rx: 4 },
    B: 226, T: 86, neckTopY: 26, surfRx: 24, surfRy: 6.5,
    gloss: [{ x: 29, y: 96, w: 8, h: 116, rx: 4, o: 0.5 }, { x: 67, y: 104, w: 3, h: 92, rx: 1.5, o: 0.22 }],
  },
  // tall slim corked vial
  vial: {
    vbH: 300, w: 100,
    interior: 'M37,70 L37,266 Q37,286 50,286 Q63,286 63,266 L63,70 Q63,66 59,66 L41,66 Q37,66 37,70 Z',
    outline: 'M43,22 L43,40 Q43,48 40,54 Q34,62 34,74 L34,268 Q34,290 50,290 Q66,290 66,268 L66,74 Q66,62 60,54 Q57,48 57,40 L57,22',
    rim: { cx: 50, cy: 22, rx: 8.5, ry: 2.6 },
    cork: { x: 41, y: 6, w: 18, h: 17, top: 11, taper: 2 },
    label: { x: 36, y: 150, w: 28, h: 70, rx: 3 },
    B: 284, T: 70, neckTopY: 22, surfRx: 12.5, surfRy: 4.5,
    gloss: [{ x: 39, y: 84, w: 6, h: 180, rx: 3, o: 0.5 }, { x: 60, y: 92, w: 2.4, h: 150, rx: 1.2, o: 0.22 }],
  },
  // round-bottom florence flask
  flask: {
    vbH: 252, w: 100,
    interior: 'M40,84 L40,128 A38,38 0 1,0 60,128 L60,84 Z',
    outline: 'M43,24 L43,118 A45,45 0 1,0 57,118 L57,24',
    rim: { cx: 50, cy: 24, rx: 8.5, ry: 2.6 },
    cork: { x: 41, y: 8, w: 18, h: 17, top: 13, taper: 2 },
    label: { x: 30, y: 150, w: 40, h: 44, rx: 20 },
    B: 224, T: 84, neckTopY: 24, surfRx: 19, surfRy: 6,
    gloss: [{ x: 26, y: 158, w: 8, h: 40, rx: 4, o: 0.45 }, { x: 45, y: 40, w: 4, h: 60, rx: 2, o: 0.4 }],
  },
};

// luminous tincture palette — brighter & more jewel-like than v1
const VESSEL_COLORS = [
  { a: '#ff90a4', b: '#e23a60', hi: '#ffd2da', name: 'rosehip' },
  { a: '#ffba5c', b: '#ef7a1a', hi: '#ffe3b0', name: 'amber' },
  { a: '#fff07a', b: '#edc23a', hi: '#fffcd0', name: 'citron' },
  { a: '#9bef84', b: '#39a83f', hi: '#d6ffc8', name: 'absinthe' },
  { a: '#79f0e0', b: '#16a39a', hi: '#cafff7', name: 'verdigris' },
  { a: '#8fc4ff', b: '#2f6fe0', hi: '#d4e8ff', name: 'cobalt' },
  { a: '#c9a6ff', b: '#7b46e6', hi: '#ecddff', name: 'amethyst' },
  { a: '#ff9ed6', b: '#e24f9e', hi: '#ffd6ee', name: 'magenta' },
];

let _uid = 0;
const BUBBLES = 7;

// ── living liquid: 3D cylinder read — elliptical sloshing surface + bubbles ──
// The column fills flat; the surface is an ELLIPSE you look down into. Slosh =
// the surface group bobs, tilts and breathes; bubbles rise and pop at the rim.
function Liquid({ S, uid, bands, capacity, agitation = 0 }) {
  const surfRef = React.useRef(null);     // <g> holding the surface ellipse + arcs
  const colTopRef = React.useRef(null);   // top band rect (its y rides the bob)
  const bubbleRefs = React.useRef([]);
  const seed = React.useRef(Math.random() * 100).current;
  const agitRef = React.useRef(agitation);
  agitRef.current = agitation;

  const cellH = (S.B - S.T) / capacity;
  const n = bands.length;
  const surfaceY = S.B - n * cellH;
  const yBotTop = S.B - (n - 1) * cellH;
  const rx = S.surfRx || 22, ry = S.surfRy || 6;
  const xL = -60, xR = 160;

  React.useEffect(() => {
    if (!n) return;
    const bs = [];
    for (let i = 0; i < BUBBLES; i++) {
      bs.push({
        x: 50 + (Math.random() - 0.5) * rx * 1.4,
        y: yBotTop - Math.random() * (yBotTop - surfaceY),
        r: 0.7 + Math.random() * 1.7,
        sp: 6 + Math.random() * 11,
        ph: Math.random() * 6,
      });
    }
    let last = performance.now() / 1000;
    const unsub = vesselClock.sub((t) => {
      const dt = Math.min(0.05, t - last); last = t;
      const ag = agitRef.current;
      // slosh: bob up/down, tilt side to side, surface "breathes" wider
      const bob = Math.sin(t * (1.5 + ag * 1.8) + seed) * (0.6 + ag * 3.2);
      const tiltS = Math.sin(t * (1.8 + ag * 2) + seed * 1.7) * (1.5 + ag * 12);
      const breathe = 1 + Math.sin(t * 2.4 + seed) * (0.03 + ag * 0.12);
      if (surfRef.current)
        surfRef.current.setAttribute('transform',
          `translate(0 ${bob.toFixed(2)}) rotate(${tiltS.toFixed(2)} 50 ${surfaceY}) scale(1 ${breathe.toFixed(3)})`);
      // the column top edge tracks the bob so liquid stays attached to surface
      if (colTopRef.current) colTopRef.current.setAttribute('y', (surfaceY + bob).toFixed(2));
      // bubbles
      for (let i = 0; i < bs.length; i++) {
        const node = bubbleRefs.current[i]; if (!node) continue;
        const bb = bs[i];
        bb.y -= bb.sp * (0.55 + ag * 1.5) * dt;
        const x = bb.x + Math.sin(t * 3 + bb.ph) * (0.4 + ag);
        if (bb.y <= surfaceY + bb.r) { bb.y = yBotTop - 1; bb.x = 50 + (Math.random() - 0.5) * rx * 1.4; }
        const fade = bb.y < surfaceY + 7 ? Math.max(0, (bb.y - surfaceY) / 7) : 1;
        node.setAttribute('cx', x.toFixed(2));
        node.setAttribute('cy', bb.y.toFixed(2));
        node.setAttribute('r', bb.r.toFixed(2));
        node.setAttribute('opacity', (0.5 * fade).toFixed(2));
      }
    });
    return unsub;
  }, [n, capacity, S]);

  if (!n) return null;
  const top = bands[n - 1];

  return (
    <g>
      {/* submerged bands */}
      {bands.slice(0, n - 1).map((band, i) => {
        const yTop = S.B - (i + 1) * cellH;
        const h = i === 0 ? cellH + 70 : cellH + 1.2;
        return <rect key={i} x={xL} y={yTop} width={xR - xL} height={h} fill={`url(#${uid}g${i})`} />;
      })}
      {/* top band column (flat fill; its top rides the bob) */}
      <rect ref={colTopRef} x={xL} y={surfaceY} width={xR - xL} height={cellH + 80} fill={`url(#${uid}g${n - 1})`} />
      {/* bubbles (behind the surface disc) */}
      <g>
        {Array.from({ length: BUBBLES }).map((_, i) => (
          <circle key={i} ref={el => bubbleRefs.current[i] = el} cx="50" cy={yBotTop} r="1"
            fill="rgba(255,255,255,0.9)" opacity="0" />
        ))}
      </g>
      {/* 3D surface disc — look down into the cylinder */}
      <g ref={surfRef}>
        <ellipse cx="50" cy={surfaceY} rx={rx} ry={ry} fill={top.hi || '#fff'} opacity="0.55" />
        <ellipse cx="50" cy={surfaceY} rx={rx} ry={ry} fill="none"
          stroke="rgba(0,0,0,0.18)" strokeWidth="1.2" />
        {/* back-rim bright crescent */}
        <path d={`M ${50 - rx * 0.7} ${surfaceY - ry * 0.5} A ${rx} ${ry} 0 0 1 ${50 + rx * 0.7} ${surfaceY - ry * 0.5}`}
          fill="none" stroke="#fff" strokeWidth="1" opacity="0.7" strokeLinecap="round" />
      </g>
    </g>
  );
}

// ── cork stopper ──
function Cork({ c, uid }) {
  if (!c) return null;
  const { x, y, w, h, top, taper } = c;
  const d = `M ${x + taper} ${top} Q ${x + taper} ${y} ${x} ${y + 1}
             L ${x} ${y + h} Q ${x} ${y + h + 2.5} ${x + 3} ${y + h + 2.5}
             L ${x + w - 3} ${y + h + 2.5} Q ${x + w} ${y + h + 2.5} ${x + w} ${y + h}
             L ${x + w} ${y + 1} Q ${x + w - taper} ${y} ${x + w - taper} ${top} Z`;
  return (
    <g>
      <path d={d} fill={`url(#${uid}cork)`} stroke="rgba(90,55,25,0.5)" strokeWidth="0.8" />
      <ellipse cx={x + w / 2} cy={top} rx={(w - 2 * taper) / 2} ry="2.4" fill="#caa06a" stroke="rgba(90,55,25,0.4)" strokeWidth="0.7" />
      {/* striations */}
      <line x1={x + 2} y1={y + h * 0.4} x2={x + w - 2} y2={y + h * 0.4} stroke="rgba(90,55,25,0.28)" strokeWidth="0.7" />
      <line x1={x + 2} y1={y + h * 0.7} x2={x + w - 2} y2={y + h * 0.7} stroke="rgba(90,55,25,0.22)" strokeWidth="0.7" />
    </g>
  );
}

// ── parchment label ──
function Label({ l, uid, accent }) {
  if (!l) return null;
  const { x, y, w, h, rx } = l;
  const cx = x + w / 2;
  return (
    <g opacity="0.96">
      <rect x={x} y={y} width={w} height={h} rx={rx} fill={`url(#${uid}lbl)`} stroke="rgba(120,90,55,0.35)" strokeWidth="0.8" />
      <circle cx={cx} cy={y + 12} r="5" fill="none" stroke={accent || '#9a6a32'} strokeWidth="0.9" opacity="0.7" />
      <circle cx={cx} cy={y + 12} r="1.8" fill={accent || '#9a6a32'} opacity="0.6" />
      {[0, 1, 2].map(i => (
        <line key={i} x1={x + 7} y1={y + 26 + i * 6} x2={x + w - 7} y2={y + 26 + i * 6}
          stroke="rgba(120,90,55,0.4)" strokeWidth="1" strokeLinecap="round" opacity={0.8 - i * 0.18} />
      ))}
    </g>
  );
}

function Vessel({
  shape = 'apothecary', bands = [], capacity = 4,
  tilt = 0, wobble = 0, width = 64, agitation = 0,
  theme = {}, glow = null, selected = false, dim = false,
  cork = true, label = false, style = {},
}) {
  const S = SHAPES[shape] || SHAPES.apothecary;
  const idRef = React.useRef(null);
  if (!idRef.current) idRef.current = 'vs' + _uid++;
  const uid = idRef.current;

  const cx = 50, cy = S.vbH / 2;
  const aspect = S.vbH / S.w;
  const liquidRot = -tilt + wobble;                 // keep surface gravity-level
  const glassTint = theme.glassTint || 'rgba(208,224,244,0.14)';
  const rimColor = theme.rim || 'rgba(255,255,255,0.92)';
  const bandObjs = bands.map(b => typeof b === 'string' ? { a: b, b, hi: '#fff' } : b);

  return (
    <svg viewBox={`0 0 ${S.w} ${S.vbH}`} width={width} height={width * aspect}
      style={{
        overflow: 'visible', display: 'block',
        transform: `rotate(${tilt}deg)`, transformOrigin: `${cx}px ${cy}px`,
        transition: selected ? 'transform .2s cubic-bezier(.34,1.4,.5,1)' : 'transform .4s ease',
        filter: glow
          ? `drop-shadow(0 0 7px ${glow}) drop-shadow(0 0 18px ${glow})`
          : 'drop-shadow(0 8px 11px rgba(60,35,12,0.30))',
        opacity: dim ? 0.42 : 1, ...style,
      }}>
      <defs>
        <clipPath id={uid + 'clip'}><path d={S.interior} /></clipPath>
        <linearGradient id={uid + 'glass'} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="rgba(255,255,255,0.34)" />
          <stop offset="0.32" stopColor={glassTint} />
          <stop offset="0.7" stopColor="rgba(120,140,170,0.10)" />
          <stop offset="1" stopColor="rgba(255,255,255,0.20)" />
        </linearGradient>
        <linearGradient id={uid + 'inner'} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="rgba(0,0,0,0.26)" />
          <stop offset="0.2" stopColor="rgba(0,0,0,0)" />
          <stop offset="0.78" stopColor="rgba(0,0,0,0)" />
          <stop offset="1" stopColor="rgba(0,0,0,0.32)" />
        </linearGradient>
        <linearGradient id={uid + 'cork'} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#c79a5e" />
          <stop offset="0.42" stopColor="#a9763f" />
          <stop offset="1" stopColor="#7c5026" />
        </linearGradient>
        <linearGradient id={uid + 'lbl'} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f7ecd3" />
          <stop offset="1" stopColor="#e9d6b0" />
        </linearGradient>
        {bandObjs.map((c, i) => (
          <linearGradient key={i} id={uid + 'g' + i} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor={c.b} />
            <stop offset="0.32" stopColor={c.a} />
            <stop offset="0.5" stopColor={c.hi || c.a} stopOpacity="0.9" />
            <stop offset="0.68" stopColor={c.a} />
            <stop offset="1" stopColor={c.b} />
          </linearGradient>
        ))}
      </defs>

      {/* glass body tint */}
      <path d={S.interior} fill={`url(#${uid}glass)`} />

      {/* living liquid */}
      <g clipPath={`url(#${uid}clip)`}>
        <g transform={`rotate(${liquidRot} ${cx} ${cy})`}>
          <Liquid S={S} uid={uid} bands={bandObjs} capacity={capacity} agitation={agitation} />
        </g>
        <rect x="0" y="0" width={S.w} height={S.vbH} fill={`url(#${uid}inner)`} />
      </g>

      {/* parchment label sits on the glass */}
      {label && <Label l={S.label} uid={uid} accent={theme.accent} />}

      {/* glass outline + rim */}
      <path d={S.outline} fill="none" stroke={rimColor} strokeWidth="2.4"
        strokeLinecap="round" strokeLinejoin="round" opacity="0.92" />
      <ellipse cx={S.rim.cx} cy={S.rim.cy} rx={S.rim.rx} ry={S.rim.ry}
        fill="none" stroke={rimColor} strokeWidth="2.2" opacity="0.9" />

      {/* cork stopper */}
      {cork && <Cork c={S.cork} uid={uid} />}

      {/* specular gloss */}
      {S.gloss.map((g, i) => (
        <rect key={i} x={g.x} y={g.y} width={g.w} height={g.h} rx={g.rx} fill="#fff" opacity={g.o} />
      ))}
    </svg>
  );
}

Object.assign(window, { Vessel, VESSEL_COLORS, VESSEL_SHAPES: SHAPES, vesselClock });
