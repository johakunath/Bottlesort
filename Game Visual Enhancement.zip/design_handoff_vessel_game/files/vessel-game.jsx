// vessel-game.jsx — full gameplay screen: themed backdrop, top HUD, the
// animated VesselScene, and a control bar. Exports window.VesselGame.

function HudBtn({ theme, label, icon }) {
  const t = theme;
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5,
      opacity: 0.9,
    }}>
      <div style={{
        width: 50, height: 50, borderRadius: 16, display: 'grid', placeItems: 'center',
        background: t.chipBg, border: t.chipBorder, color: t.chipFg,
        fontSize: 21, boxShadow: t.neon ? `inset 0 0 0 1px ${t.accent}44` : '0 1px 2px rgba(0,0,0,0.2)',
      }}>{icon}</div>
      <span style={{ fontFamily: t.bodyFont, fontSize: 10.5, letterSpacing: '0.08em',
        textTransform: 'uppercase', color: t.fg, opacity: 0.6 }}>{label}</span>
    </div>
  );
}

function VesselGame({ theme = {} }) {
  const t = theme;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      position: 'relative', color: t.fg, overflow: 'hidden',
    }}>
      {/* top HUD */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '58px 24px 8px', zIndex: 3,
      }}>
        <div style={{
          width: 42, height: 42, borderRadius: 13, display: 'grid', placeItems: 'center',
          background: t.chipBg, border: t.chipBorder, color: t.chipFg, fontSize: 18,
        }}>‹</div>
        <div style={{ textAlign: 'center', flex: 1, minWidth: 0, padding: '0 8px' }}>
          <div style={{ fontFamily: t.headFont, fontSize: 19, fontWeight: 600,
            color: t.titleColor || t.fg, letterSpacing: '0.02em', whiteSpace: 'nowrap',
            textShadow: t.neon ? `0 0 12px ${t.accent}88` : 'none' }}>{t.levelLabel}</div>
          <div style={{ fontFamily: t.bodyFont, fontSize: 11, opacity: 0.6, whiteSpace: 'nowrap',
            letterSpacing: '0.16em', textTransform: 'uppercase', marginTop: 2 }}>{t.levelSub}</div>
        </div>
        <div style={{
          fontFamily: t.headFont, fontSize: 15, fontWeight: 600,
          padding: '9px 14px', borderRadius: 999, background: t.chipBg,
          border: t.chipBorder, color: t.chipFg, minWidth: 42, textAlign: 'center',
        }}>{t.moves}</div>
      </div>

      {/* the animated tray */}
      <div style={{ flex: 1, minHeight: 0, zIndex: 2 }}>
        <VesselScene theme={t} />
      </div>

      {/* control bar */}
      <div style={{
        display: 'flex', justifyContent: 'center', gap: 30,
        padding: '4px 0 30px', zIndex: 3,
      }}>
        <HudBtn theme={t} label="Undo" icon="↺" />
        <HudBtn theme={t} label="Hint" icon="✦" />
        <HudBtn theme={t} label="Reset" icon="⟳" />
      </div>
    </div>
  );
}

Object.assign(window, { VesselGame });