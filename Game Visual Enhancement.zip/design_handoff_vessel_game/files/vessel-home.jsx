// vessel-home.jsx — themed menu / home screen. Hero arrangement of filled
// vessels (gently bobbing), wordmark, primary CTA, level chips.
// Exports window.VesselHome (props: theme).

function VesselHome({ theme = {} }) {
  const t = theme;
  const C = window.VESSEL_COLORS;
  // hero vessels — pretty layered fills
  const hero = [
    { shape: t.shape || 'classic', bands: [C[0], C[5], C[2], C[3]] },
    { shape: t.shape || 'classic', bands: [C[6], C[3], C[5], C[1]] },
    { shape: t.shape || 'classic', bands: [C[4], C[1], C[7], C[5]] },
  ];

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'space-between',
      padding: '70px 26px 40px', boxSizing: 'border-box', position: 'relative',
      color: t.fg || '#fff',
    }}>
      {/* wordmark */}
      <div style={{ textAlign: 'center', zIndex: 2 }}>
        <div style={{
          fontFamily: t.headFont, fontSize: 13, letterSpacing: '0.42em',
          textTransform: 'uppercase', opacity: 0.66, marginBottom: 10,
          color: t.accent,
        }}>{t.kicker}</div>
        <h1 style={{
          fontFamily: t.headFont, fontSize: 64, lineHeight: 0.92, margin: 0,
          fontWeight: t.headWeight || 600, letterSpacing: t.headTrack || '-0.01em',
          color: t.titleColor || t.fg,
          textShadow: t.neon ? `0 0 18px ${t.accent}, 0 0 40px ${t.accent}66` : 'none',
        }}>Vessel</h1>
        <p style={{
          fontFamily: t.bodyFont, fontSize: 15, margin: '12px 0 0', opacity: 0.7,
          letterSpacing: '0.02em',
        }}>{t.tagline}</p>
      </div>

      {/* hero vessels */}
      <div style={{
        display: 'flex', gap: 18, alignItems: 'flex-end', zIndex: 2,
        perspective: '700px',
      }}>
        {hero.map((h, i) => (
          <div key={i} style={{
            animation: `vsBob 3.4s ease-in-out ${i * 0.4}s infinite`,
            transform: `translateZ(0)`,
          }}>
            <Vessel shape={h.shape} bands={h.bands} capacity={4}
              width={i === 1 ? 78 : 64}
              theme={{ glassTint: t.glassTint, rim: t.rim }}
              glow={t.neon ? h.bands[h.bands.length - 1].a : null} />
          </div>
        ))}
      </div>

      {/* CTA + chips */}
      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 18, alignItems: 'center', zIndex: 2 }}>
        <button style={{
          fontFamily: t.headFont, fontSize: 19, letterSpacing: '0.04em',
          padding: '17px 0', width: '100%', borderRadius: t.btnRadius || 16,
          border: t.btnBorder || 'none', cursor: 'pointer',
          background: t.btnBg, color: t.btnFg,
          boxShadow: t.btnShadow,
          fontWeight: 600,
        }}>{t.cta}</button>
        <div style={{ display: 'flex', gap: 10 }}>
          {['Daily', 'Levels', 'Zen'].map((c, i) => (
            <div key={c} style={{
              fontFamily: t.bodyFont, fontSize: 12.5, letterSpacing: '0.05em',
              padding: '9px 16px', borderRadius: 999,
              border: t.chipBorder, background: t.chipBg, color: t.chipFg,
              opacity: i === 0 ? 1 : 0.7,
            }}>{c}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { VesselHome });