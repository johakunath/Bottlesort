// app.jsx — defines the two proposal themes, a backdrop-wrapped Screen, and
// lays out four phone mockups on the design canvas.

const APO = {
  name: 'apothecary', shape: 'classic', neon: false,
  headFont: '"Fraunces", serif', headWeight: 600, headTrack: '-0.015em',
  bodyFont: '"Spectral", serif',
  fg: '#f1e2cd', titleColor: '#f7e8d2', accent: '#e3a85c',
  glassTint: 'rgba(255,220,170,0.10)', rim: 'rgba(255,236,205,0.88)',
  vesselWidth: 60,
  kicker: 'The Apothecary', tagline: 'Decant, settle, set in order.', cta: 'Begin the Decanting',
  btnBg: 'linear-gradient(#f0c074, #d18b34)', btnFg: '#3a2410',
  btnShadow: '0 6px 16px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.5)',
  btnRadius: 14, btnBorder: 'none',
  chipBg: 'rgba(255,222,176,0.07)', chipBorder: '1px solid rgba(255,214,156,0.28)', chipFg: '#f0dcc0',
  levelLabel: 'Tincture No. 7', levelSub: 'Amber Cabinet', moves: '14',
  solvedText: 'Settled',
};

const NEON = {
  name: 'neon', shape: 'tall', neon: true,
  headFont: '"Chakra Petch", sans-serif', headWeight: 700, headTrack: '0.01em',
  bodyFont: '"Space Grotesk", sans-serif',
  fg: '#dcecff', titleColor: '#ffffff', accent: '#ff4cc6',
  glassTint: 'rgba(120,200,255,0.08)', rim: 'rgba(190,240,255,0.85)',
  vesselWidth: 52,
  kicker: 'Arcade Mode', tagline: 'Sort to the beat.', cta: 'PLAY',
  btnBg: 'linear-gradient(90deg, #ff4cc6, #7a3cff 55%, #34d6ff)', btnFg: '#0c0718',
  btnShadow: '0 0 18px rgba(255,76,198,0.6), 0 6px 18px rgba(0,0,0,0.5)',
  btnRadius: 12, btnBorder: 'none',
  chipBg: 'rgba(120,40,200,0.20)', chipBorder: '1px solid rgba(255,80,200,0.4)', chipFg: '#ffd8f4',
  levelLabel: 'STAGE 07', levelSub: 'Neon Run', moves: '14',
  solvedText: 'CLEARED',
};

function Backdrop({ theme }) {
  if (theme.neon) {
    return (
      <div className="bg-neon">
        <div className="sun" />
        <div className="horizon" />
        <div className="grid" />
        <div className="scan" />
      </div>
    );
  }
  return (
    <div className="bg-apo"><div className="apo-glow" /></div>
  );
}

function Screen({ theme, kind }) {
  if (theme.name === 'apothecary') {
    return kind === 'home' ? <ApoHome theme={theme} /> : <ApoGame theme={theme} />;
  }
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <Backdrop theme={theme} />
      <div style={{ position: 'absolute', inset: 0, zIndex: 1 }}>
        {kind === 'home'
          ? <VesselHome theme={theme} />
          : <VesselGame theme={theme} />}
      </div>
    </div>
  );
}

const DEV_W = 384, DEV_H = 812;

function Phone({ theme, kind }) {
  return (
    <IOSDevice width={DEV_W} height={DEV_H} dark={true}>
      <Screen theme={theme} kind={kind} />
    </IOSDevice>
  );
}

function App() {
  const abW = DEV_W + 48, abH = DEV_H + 54;
  return (
    <DesignCanvas>
      <DCSection id="apo" title="Proposal A · The Apothecary — sunlit shelf, corked glassware, living liquid (tap ☀/☾)">
        <DCArtboard id="apo-home" label="Home" width={abW} height={abH} bg="#e7cf9f">
          <div style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}>
            <Phone theme={APO} kind="home" />
          </div>
        </DCArtboard>
        <DCArtboard id="apo-game" label="Gameplay · auto-pours" width={abW} height={abH} bg="#e7cf9f">
          <div style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}>
            <Phone theme={APO} kind="game" />
          </div>
        </DCArtboard>
      </DCSection>

      <DCSection id="neon" title="Proposal B · Neon Arcade — glowing liquids, synth grid, dark">
        <DCArtboard id="neon-home" label="Home" width={abW} height={abH} bg="#0c0718">
          <div style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}>
            <Phone theme={NEON} kind="home" />
          </div>
        </DCArtboard>
        <DCArtboard id="neon-game" label="Gameplay · auto-pours" width={abW} height={abH} bg="#0c0718">
          <div style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}>
            <Phone theme={NEON} kind="game" />
          </div>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);