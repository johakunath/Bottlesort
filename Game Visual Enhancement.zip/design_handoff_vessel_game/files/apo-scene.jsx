// apo-scene.jsx — apothecary gameplay tray. Auto-plays a believable sort:
// a corked bottle lifts (cork pops), arcs over the target, tilts and pours an
// arcing stream; liquid transfers band-by-band with a ripple + droplets, then
// the bottle returns and re-corks. Liquid sloshes & bubbles throughout.
// Exports window.ApoScene (props: theme, dark).

const APO_LEVELS = [
  [ [0,1,2,0], [1,2,0,1], [2,0,1,2], [], [] ],
];
const APO_SHAPELIST = ['round', 'flask', 'vial', 'flask', 'round'];
const APO_CAP = 4;
const APO_EASE = 'cubic-bezier(.34,.02,.2,1)';

function apoClone(l) { return l.map(b => b.slice()); }
function apoTopRun(b) {
  if (!b.length) return { color: -1, n: 0 };
  const c = b[b.length - 1]; let n = 0;
  for (let i = b.length - 1; i >= 0 && b[i] === c; i--) n++;
  return { color: c, n };
}
function apoMoves(bottles, cap) {
  const moves = [];
  for (let i = 0; i < bottles.length; i++) {
    const from = bottles[i];
    if (!from.length) continue;
    const tr = apoTopRun(from);
    if (tr.n === from.length && new Set(from).size === 1) continue;
    for (let j = 0; j < bottles.length; j++) {
      if (i === j) continue;
      const to = bottles[j];
      if (to.length >= cap) continue;
      if (to.length === 0 || to[to.length - 1] === tr.color) moves.push([i, j, tr]);
    }
  }
  return moves;
}
function apoPick(bottles, cap) {
  const ms = apoMoves(bottles, cap);
  if (!ms.length) return null;
  ms.sort((a, b) => {
    const an = bottles[a[1]].length, bn = bottles[b[1]].length;
    return (bn > 0) - (an > 0) || bn - an;
  });
  return ms[0];
}

function ApoScene({ theme = {}, dark = false }) {
  const C = window.APO_COLORS;
  const [bottles, setBottles] = React.useState(() => apoClone(APO_LEVELS[0]));
  const [anim, setAnim] = React.useState(null);   // {from,to,phase,dx,dy,tilt,side,color}
  const [stream, setStream] = React.useState(null); // {x1,y1,cx,cy,x2,y2,color}
  const [wobble, setWobble] = React.useState(0);
  const [parallax, setParallax] = React.useState({ x: 0, y: 0 });
  const [solved, setSolved] = React.useState(false);

  const slotRefs = React.useRef([]);
  const trayRef = React.useRef(null);
  const timers = React.useRef([]);
  const after = (ms, fn) => { const id = setTimeout(fn, ms); timers.current.push(id); };
  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };

  // gentle parallax from pointer / device tilt
  React.useEffect(() => {
    const onMove = (e) => {
      const px = (e.clientX / window.innerWidth - 0.5) * 2;
      const py = (e.clientY / window.innerHeight - 0.5) * 2;
      setParallax({ x: px, y: py });
    };
    const onOrient = (e) => {
      if (e.gamma == null) return;
      setParallax({
        x: Math.max(-1, Math.min(1, e.gamma / 30)),
        y: Math.max(-1, Math.min(1, (e.beta - 45) / 30)),
      });
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('deviceorientation', onOrient);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('deviceorientation', onOrient);
    };
  }, []);

  // measure the arc between source mouth and target surface (tray-local coords)
  const measureStream = (fi, ti, side, color) => {
    const tray = trayRef.current;
    const sEl = slotRefs.current[fi], tEl = slotRefs.current[ti];
    if (!tray || !sEl || !tEl) return null;
    const tr = tray.getBoundingClientRect();
    const s = sEl.getBoundingClientRect(), t = tEl.getBoundingClientRect();
    const x1 = (s.left + s.width / 2) - tr.left + side * (s.width * 0.16);
    const y1 = (s.top) - tr.top + s.height * 0.16;
    const x2 = (t.left + t.width / 2) - tr.left;
    const y2 = (t.top) - tr.top + t.height * 0.30;
    const cx = x1 + (x2 - x1) * 0.35 + side * 10;
    const cy = Math.min(y1, y2) - 6;
    return { x1, y1, cx, cy, x2, y2, color };
  };

  // the pour loop
  React.useEffect(() => {
    let alive = true;
    const step = (state) => {
      if (!alive) return;
      const mv = apoPick(state, APO_CAP);
      if (!mv) {
        setSolved(true);
        after(1500, () => setSolved(false));
        after(2300, () => { const fresh = apoClone(APO_LEVELS[0]); setBottles(fresh); after(800, () => step(fresh)); });
        return;
      }
      const [fi, ti, tr] = mv;
      const moveN = Math.min(tr.n, APO_CAP - state[ti].length);
      const color = tr.color;
      const sEl = slotRefs.current[fi], tEl = slotRefs.current[ti];
      let dx = 0, dy = -120, side = 1, tilt = 0;
      if (sEl && tEl) {
        const sr = sEl.getBoundingClientRect(), trc = tEl.getBoundingClientRect();
        side = trc.left >= sr.left ? 1 : -1;
        dx = (trc.left - sr.left) + side * -10;
        dy = (trc.top - sr.top) - sr.height * 0.66;
        tilt = side * 62;
      }

      // 1 · lift + uncork
      setAnim({ from: fi, to: ti, phase: 'lift', dx: 0, dy: -40, tilt: side * 4, side, color });
      // 2 · carry across
      after(460, () => setAnim(a => a && { ...a, phase: 'carry', dx, dy, tilt: tilt * 0.4 }));
      // 3 · tilt & pour
      after(1000, () => {
        setAnim(a => a && { ...a, phase: 'pour', tilt });
        const stm = measureStream(fi, ti, side, color);
        if (stm) setStream(stm);
      });
      // transfer band-by-band so the levels visibly change
      for (let k = 0; k < moveN; k++) {
        after(1260 + k * 260, () => {
          if (!alive) return;
          setBottles(prev => {
            const nx = prev.map(b => b.slice());
            if (nx[fi].length) { const col = nx[fi].pop(); nx[ti].push(col); }
            return nx;
          });
        });
      }
      const pourEnd = 1260 + moveN * 260 + 180;
      // 4 · stop stream, untilt
      after(pourEnd, () => { setStream(null); setAnim(a => a && { ...a, phase: 'carry', tilt: tilt * 0.3 }); });
      // 5 · return + re-cork
      after(pourEnd + 220, () => setAnim(a => a && { ...a, phase: 'return', dx: 0, dy: -40, tilt: side * 3 }));
      after(pourEnd + 640, () => setAnim(null));
      // next
      after(pourEnd + 980, () => setBottles(cur => { step(cur); return cur; }));
    };
    after(1000, () => step(apoClone(APO_LEVELS[0])));
    return () => { alive = false; clearTimers(); };
  }, []);

  // slosh wobble while the bottle is in motion
  React.useEffect(() => {
    if (!anim || anim.phase === 'return') { setWobble(0); return; }
    let raf, t0 = performance.now();
    const amp = anim.phase === 'pour' ? 4 : 7;
    const tick = (now) => {
      const e = (now - t0) / 1000;
      setWobble(Math.sin(e * 6.5) * amp * Math.exp(-e * 0.3));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [anim?.phase]);

  // map color indices → gradient band objects
  const bandsOf = (b) => b.map(ci => C[ci % C.length]);
  const rows = [[0, 1, 2], [3, 4]];
  const px = parallax.x, py = parallax.y;

  return (
    <div ref={trayRef} style={{
      position: 'relative', width: '100%', height: '100%',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      perspective: '1000px', perspectiveOrigin: '50% 38%',
    }}>
      <div style={{
        display: 'flex', flexDirection: 'column', gap: 'clamp(30px,7vh,58px)',
        alignItems: 'center',
        transform: `rotateX(${(-py * 4).toFixed(2)}deg) rotateY(${(px * 6).toFixed(2)}deg) translate(${(px * 9).toFixed(1)}px, ${(py * 5).toFixed(1)}px)`,
        transformStyle: 'preserve-3d',
        transition: 'transform .3s ease-out',
      }}>
        {rows.map((row, ri) => (
          <div key={ri} style={{ display: 'flex', gap: 'clamp(16px,5.5vw,34px)', alignItems: 'flex-end' }}>
            {row.map((i) => {
              const b = bottles[i] || [];
              const isSrc = anim && anim.from === i;
              const isTgt = anim && anim.to === i;
              const pouring = isSrc && anim.phase === 'pour';
              const lift = isSrc ? { dx: anim.dx, dy: anim.dy, tilt: anim.tilt } : { dx: 0, dy: 0, tilt: 0 };
              const depth = ri === 0 ? 18 : -26;        // front row forward
              return (
                <div key={i} ref={el => slotRefs.current[i] = el}
                  style={{ position: 'relative', transform: `translateZ(${depth}px)`, transformStyle: 'preserve-3d' }}>
                  {/* shelf shadow */}
                  <div style={{
                    position: 'absolute', left: '50%', bottom: -12, width: '76%', height: 15,
                    transform: `translateX(-50%) scale(${isSrc ? 0.55 : 1})`,
                    background: `radial-gradient(ellipse, ${dark ? 'rgba(0,0,0,0.5)' : 'rgba(90,60,30,0.4)'}, transparent 70%)`,
                    filter: 'blur(4px)', opacity: isSrc ? 0.3 : 0.7, transition: 'all .45s ease',
                  }} />
                  <div style={{
                    transform: `translate(${lift.dx}px, ${lift.dy}px)`,
                    transition: `transform ${anim && (anim.phase === 'carry' || anim.phase === 'return') ? '0.5s' : '0.42s'} ${APO_EASE}`,
                    zIndex: isSrc ? 50 : 1, position: 'relative', willChange: 'transform',
                    animation: !anim ? `apoBob 4.${i}s ease-in-out ${i * 0.3}s infinite` : 'none',
                  }}>
                    <ApoVessel
                      shape={APO_SHAPELIST[i]}
                      bands={bandsOf(b)}
                      capacity={APO_CAP}
                      tilt={lift.tilt}
                      wobble={isSrc ? wobble : 0}
                      width={theme.vesselWidth || 70}
                      corkLift={pouring ? 26 : 0}
                      dark={dark}
                    />
                    {/* steam wisp rising from an open bottle */}
                    {pouring && (
                      <div style={{
                        position: 'absolute', top: -6, left: anim.side > 0 ? '64%' : '36%',
                        width: 16, height: 30, borderRadius: '50%',
                        background: 'radial-gradient(ellipse at bottom, rgba(255,255,255,0.5), transparent 70%)',
                        filter: 'blur(3px)', transformOrigin: 'bottom center',
                        animation: 'apoSteam 1.4s ease-out infinite',
                      }} />
                    )}
                  </div>
                  {/* landing ripple + droplets on the receiving bottle */}
                  {isTgt && anim.phase === 'pour' && (
                    <React.Fragment>
                      <div style={{
                        position: 'absolute', left: '50%', top: '30%', width: 22, height: 7,
                        borderRadius: '50%', border: `1.5px solid ${C[anim.color].a}`,
                        animation: 'apoRipple .7s ease-out infinite',
                      }} />
                      {[0, 1].map(d => (
                        <div key={d} style={{
                          position: 'absolute', left: `${46 + d * 8}%`, top: '24%',
                          width: 4, height: 4, borderRadius: '50%', background: C[anim.color].a,
                          ['--dropY']: '20px',
                          animation: `apoDrop .5s ease-in ${d * 0.18}s infinite`,
                        }} />
                      ))}
                    </React.Fragment>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* arcing pour stream overlay (tray-local px units, no viewBox) */}
      {stream && (
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible', pointerEvents: 'none', zIndex: 60 }}>
          <defs>
            <linearGradient id="apoStreamGrad" gradientUnits="userSpaceOnUse"
              x1={0} y1={stream.y1} x2={0} y2={stream.y2}>
              <stop offset="0" stopColor={C[stream.color].a} />
              <stop offset="1" stopColor={C[stream.color].b} />
            </linearGradient>
          </defs>
          {/* soft glow underlay */}
          <path d={`M ${stream.x1} ${stream.y1} Q ${stream.cx} ${stream.cy} ${stream.x2} ${stream.y2}`}
            fill="none" stroke={C[stream.color].a} strokeWidth="10" strokeLinecap="round"
            opacity="0.35" style={{ filter: 'blur(3px)' }} />
          {/* bright core */}
          <path d={`M ${stream.x1} ${stream.y1} Q ${stream.cx} ${stream.cy} ${stream.x2} ${stream.y2}`}
            fill="none" stroke="url(#apoStreamGrad)" strokeWidth="5" strokeLinecap="round"
            style={{ animation: 'apoStreamGrow .18s ease-out' }} />
          {/* flowing highlight */}
          <path d={`M ${stream.x1} ${stream.y1} Q ${stream.cx} ${stream.cy} ${stream.x2} ${stream.y2}`}
            fill="none" stroke="rgba(255,255,255,0.85)" strokeWidth="1.6" strokeLinecap="round"
            strokeDasharray="5 14" style={{ animation: 'apoFlow .5s linear infinite' }} />
        </svg>
      )}

      {solved && (
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: theme.headFont, fontSize: 34, letterSpacing: '0.04em',
          color: theme.accent, fontStyle: 'italic',
          textShadow: dark ? '0 0 18px rgba(255,190,110,0.6)' : '0 2px 8px rgba(120,80,30,0.4)',
          animation: 'vsSolved 1.5s ease-out',
        }}>{theme.solvedText || 'Settled'}</div>
      )}
    </div>
  );
}

Object.assign(window, { ApoScene });
